// Copyright (c) 2013, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

/// Import `async.dart` instead.
@Deprecated("Will be removed in async 2.0.0.")
library dart.pkg.async.stream_zip;

export "src/stream_zip.dart";
