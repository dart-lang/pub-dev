// Copyright (c) 2013, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

/// Import `async.dart` instead.
@Deprecated("Will be removed in async 2.0.0.")
library dart.pkg.async.results;

export "src/result.dart";
export "src/result/capture_transformer.dart";
export "src/result/error.dart";
export "src/result/release_transformer.dart";
export "src/result/value.dart";
